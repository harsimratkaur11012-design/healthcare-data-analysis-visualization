"""
Healthcare Predictive Analytics: 30-Day Hospital Readmission Prediction
Author: Healthcare Data Science & Clinical Informatics Team
Description:
    This script loads historical patient admission data, performs preprocessing,
    trains Logistic Regression and Random Forest models, performs threshold analysis,
    evaluates classification performance, and exports model artifacts.
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report
)

def run_pipeline():
    print("=" * 65)
    print("  HEALTHCARE PREDICTIVE ANALYTICS: 30-DAY READMISSION MODEL")
    print("=" * 65)

    # 1. Load dataset
    data_path = "hospital_readmission_data.csv"
    print(f"\n[1] Loading patient data from '{data_path}'...")
    df = pd.read_csv(data_path)
    print(f"    Loaded {len(df)} patient records with {df.shape[1]} features.")
    readmit_rate = df["Readmitted_30Days"].mean() * 100
    print(f"    Baseline 30-day readmission rate: {readmit_rate:.2f}%")

    # 2. Feature selection and encoding
    numeric_features = [
        "Age", "LengthOfStay_Days", "NumPriorAdmissions",
        "NumEmergencyVisitsLastYear", "NumPrescribedMedications",
        "Diabetes", "Hypertension", "CongestiveHeartFailure",
        "COPD", "ChronicKidneyDisease", "CharlsonComorbidityIndex",
        "Hemoglobin_A1C"
    ]
    categorical_features = ["Gender", "AdmissionType", "DischargeDisposition"]

    X_raw = df[numeric_features + categorical_features]
    X = pd.get_dummies(X_raw, drop_first=True)
    y = df["Readmitted_30Days"]

    # 3. Train-test split (stratified)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    print(f"    Training cohort: {X_train.shape[0]} patients | Test cohort: {X_test.shape[0]} patients")

    # 4. Train Models
    print("\n[2] Training Predictive Classifiers...")
    
    # Model A: Logistic Regression (Interpretable Clinical Baseline)
    lr = LogisticRegression(max_iter=1000, random_state=42)
    lr.fit(X_train, y_train)

    # Model B: Random Forest Classifier (Non-linear ensemble)
    rf = RandomForestClassifier(n_estimators=120, max_depth=6, random_state=42)
    rf.fit(X_train, y_train)

    # 5. Model Evaluation
    models = {
        "Logistic Regression": (lr, lr.predict(X_test), lr.predict_proba(X_test)[:, 1]),
        "Random Forest Classifier": (rf, rf.predict(X_test), rf.predict_proba(X_test)[:, 1])
    }

    print("\n[3] Model Evaluation Summary:")
    print("-" * 65)
    print(f"{'Model':<26} | {'Accuracy':<8} | {'Recall':<7} | {'Precision':<9} | {'ROC-AUC':<8}")
    print("-" * 65)

    for name, (clf, preds, probs) in models.items():
        acc = accuracy_score(y_test, preds)
        rec = recall_score(y_test, preds)
        prec = precision_score(y_test, preds, zero_division=0)
        auc = roc_auc_score(y_test, probs)
        print(f"{name:<26} | {acc:<8.4f} | {rec:<7.4f} | {prec:<9.4f} | {auc:<8.4f}")

    print("-" * 65)

    # 6. Detailed RF Confusion Matrix & Insights
    rf_preds = models["Random Forest Classifier"][1]
    cm = confusion_matrix(y_test, rf_preds)
    print("\n[4] Random Forest Confusion Matrix:")
    print(f"    True Negatives (Correctly identified non-readmitted): {cm[0, 0]}")
    print(f"    False Positives (Predicted readmitted, but wasn't):  {cm[0, 1]}")
    print(f"    False Negatives (Missed readmission):                 {cm[1, 0]}")
    print(f"    True Positives (Successfully caught high risk):       {cm[1, 1]}")

    # 7. Feature Importance Ranking
    print("\n[5] Top 5 Readmission Risk Predictors (Clinical Drivers):")
    feat_imp = pd.Series(rf.feature_importances_, index=X.columns).sort_values(ascending=False)
    for i, (feat, score) in enumerate(feat_imp.head(5).items(), start=1):
        print(f"    {i}. {feat:<30} Importance: {score:.4f}")

    print("\n[6] Clinical Recommendation:")
    print("    Implement targeted post-discharge follow-up within 48-72 hours")
    print("    for patients flagged with RF predicted probability > 0.50.")
    print("=" * 65)

if __name__ == "__main__":
    run_pipeline()
