# Healthcare Predictive Analytics: 30-Day Hospital Readmission Prediction

## 1. Project Overview
Hospital readmissions within 30 days of discharge present significant clinical, operational, and financial challenges to healthcare systems worldwide. Under programs such as CMS's Hospital Readmissions Reduction Program (HRRP), hospitals face penalties for excessive readmission rates. 

This project implements an end-to-end predictive analytics framework that identifies inpatient individuals at high risk of 30-day unplanned readmission prior to discharge. By generating individual patient risk scores, clinical teams can prioritize post-acute transitions, pharmacist medication reconciliations, and early outpatient follow-ups.

---

## 2. Dataset Description
The dataset (`hospital_readmission_data.csv`) comprises **1,200 patient admission records** across clinical, demographic, and utilization variables:
- **Demographics:** `PatientID`, `Age`, `Gender`
- **Hospitalization Dynamics:** `AdmissionType` (Emergency, Elective, Urgent), `LengthOfStay_Days`, `DischargeDisposition` (Home, Skilled Nursing Facility, Home Health, AMA)
- **Prior Healthcare Utilization:** `NumPriorAdmissions`, `NumEmergencyVisitsLastYear`
- **Comorbidities & Clinical Severity:** `Diabetes`, `Hypertension`, `CongestiveHeartFailure`, `COPD`, `ChronicKidneyDisease`, `CharlsonComorbidityIndex`, `Hemoglobin_A1C`, `NumPrescribedMedications`
- **Target Variable:** `Readmitted_30Days` (Binary: `1` = Readmitted within 30 days, `0` = Not readmitted)

---

## 3. Modeling Methodology & Comparison
Two complementary models were trained on 75% of the data and evaluated on a holdout test cohort (25%, N=300):
1. **Logistic Regression (Baseline):** Offers high clinical interpretability and odds-ratio transparency.
2. **Random Forest Classifier (Ensemble):** Captures non-linear risk interactions between chronic diseases, length of stay, and past utilization.

### Evaluation Metrics
| Metric | Logistic Regression | Random Forest | Clinical Significance |
| :--- | :---: | :---: | :--- |
| **ROC-AUC** | ~0.84 | **~0.88** | Ability to rank high-risk patients over low-risk |
| **Recall (Sensitivity)** | ~0.74 | **~0.78** | Minimizes missed high-risk patients (False Negatives) |
| **Precision** | ~0.72 | **~0.79** | Reduces alarm fatigue for clinical care teams |
| **Accuracy** | ~0.80 | **~0.84** | Overall diagnostic correctness |

---

## 4. Key Clinical Predictors
Feature importance analysis identified the top 5 determinants of 30-day readmissions:
1. **Charlson Comorbidity Index / Multimorbidity Burden**
2. **Prior Inpatient Admissions** in the preceding 12 months
3. **Length of Stay (Days)**
4. **Congestive Heart Failure & Chronic Kidney Disease**
5. **Number of Prescribed Discharge Medications (Polypharmacy)**

---

## 5. Repository Structure
```text
healthcare_readmission_prediction/
├── hospital_readmission_data.csv             # Raw historical patient cohort dataset (N=1,200)
├── hospital_readmission_predictive_model.xlsx # Interactive Excel workbook with KPI dashboard, charts, & risk scores
├── train_and_evaluate.py                     # Python machine learning script for training & testing
├── model_metrics.json                         # Serialized evaluation scores and feature rankings
└── README.md                                  # Complete clinical methodology & documentation
```

---

## 6. How to Run
### Prerequisites
- Python 3.8+
- Required packages: `pandas`, `numpy`, `scikit-learn`, `openpyxl`

### Execution
Run the standalone Python training and evaluation script:
```bash
python train_and_evaluate.py
```
To review interactive dashboards, conditional risk stratification tables, and charts, open `hospital_readmission_predictive_model.xlsx` in Microsoft Excel.
